import React from 'react';

function Dog() {
  return <div>Собака</div>;
}

export default Dog;
