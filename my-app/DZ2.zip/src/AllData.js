import React from 'react';

function AllData({ props, children }) {
  return (
    <div>
      {props}
      {children}
    </div>
  );
}

export default AllData;
