import React from 'react';

function PersonProp(props) {
  return <div>{props.character}</div>;
  console.log(props);
}

export default PersonProp;
