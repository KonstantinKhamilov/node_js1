import React from 'react';

function PersonChild({ children }) {
  return <div>{children}</div>;
  console.log(children);
}

export default PersonChild;
