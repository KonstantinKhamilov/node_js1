import React from 'react';

function Sidebar({ info }) {
  return <aside>{info.content}</aside>;
}

export default Sidebar;