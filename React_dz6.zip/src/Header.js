import React from 'react';

function Header({ info }) {
  return <header>{info.title}</header>;
}

export default Header;