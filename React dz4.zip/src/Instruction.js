import React, { Component } from 'react';
import image1 from './image1.jpg';
import image2 from './image2.png';
import image3 from './image3.jpg';

class Instruction extends Component {
  constructor(props) {
    super(props);
    this.state = {
        images: [
          { id: 1, src: image1, visible: false },
          { id: 2, src: image2, visible: false },
          { id: 3, src: image3, visible: false },
        ],
      };            
  }

  toggleImage = (id) => {
    this.setState((prevState) => ({
      images: prevState.images.map((img) =>
        img.id === id ? { ...img, visible: !img.visible } : img
      ),
    }));
  };

  render() {
    return (
      <div>
        {this.state.images.map((img) => (
          <div key={img.id}>
            <button onClick={() => this.toggleImage(img.id)}>
              Toggle Image {img.id}
            </button>
            {img.visible && <img src={img.src} alt="" style={{width: '100px', height: '100px'}} />}
          </div>
        ))}
      </div>
    );
  }  
}

export default Instruction;
