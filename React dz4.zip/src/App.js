import React from 'react';
import HomeworkPage from './HomeworkPage';

function App() {
  return (
    <div className="App">
      <HomeworkPage />
    </div>
  );
}

export default App;