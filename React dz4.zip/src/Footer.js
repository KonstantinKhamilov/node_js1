import React from 'react';

function Footer({ info }) {
  return <footer>{info.text}</footer>;
}

export default Footer;