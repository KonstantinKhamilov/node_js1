/*const yodasay = require ('yodasay');
console.log(yodasay.say({
    text: 'bananas'
}));*/

const cowsay = require ('cowsay');
console.log(cowsay.say({
    text :"'Привет, мир!''До свидания!''Случайный текст'"
}));